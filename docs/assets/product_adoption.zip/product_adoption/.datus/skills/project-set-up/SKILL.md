---
name: project-set-up
description: >
  Reverse-initialize a data-project knowledge base from historical SQL / ETL scripts. Extract reusable knowledge from existing SQL files, production scripts, ETL jobs, or project code, including project structure, data layers, table lineage, field lineage, business rules, technical standards, batch conventions, naming patterns, hard-coded mappings, and development patterns. Use when the user asks to initialize a project, distill knowledge from SQL, reverse-analyze ETL, organize technical standards, extract lineage, generate project documentation, summarize development patterns, extract metric definitions, or extract rules from legacy scripts.
tags: [project, init, sql, etl, lineage, knowledge-base, reverse-engineering]
version: "1.2.0"
user_invocable: true
---

# SQL Project Reverse Initialization

Reverse-extract a reusable project knowledge base from historical SQL / ETL scripts and generate Markdown documents that later agents can use.

## Principles

1. **Domain-neutral**: do not assume any specific business domain, database, table, metric, status code, or project rule. Extract all knowledge from SQL / ETL files.
2. **Extract, do not summarize**: the goal is reusable rules and patterns, not a simple file summary.
3. **Evidence-driven**: every conclusion must cite source files and SQL evidence. Do not write unsupported inference as confirmed fact.
4. **Resolve before writing**: uncertainties that affect conclusions must be confirmed before being written into final documents. Final documents must not contain unresolved question lists.
5. **Read-only**: do not perform database writes, including `INSERT`, `UPDATE`, `DELETE`, `CREATE`, `ALTER`, or `DROP`.

## Out Of Scope

Use another workflow for:

- Running production ETL.
- Creating, modifying, or deleting database objects.
- Writing, updating, or deleting business data.
- Publishing or scheduling jobs.
- Directly calculating business metric values.
- Repairing production data.

## Inputs

The user should provide one or more of:

- SQL file directory.
- One or more SQL file paths.
- ETL script directory.
- Project code directory.

If no SQL file or directory is specified, ask the user to confirm the analysis scope.

If no output path is specified, use this default document structure:

```text
AGENTS.md
docs/business_knowledge.md
docs/technical_standards.md
docs/table_lineage.md
docs/ref_sql_inventory.md
```

## Output Documents

| Document | Purpose |
|---|---|
| `AGENTS.md` | Project overview, architecture, directories, core assets, development conventions |
| `docs/business_knowledge.md` | Business rules, metric definitions, status codes, filters, special handling |
| `docs/technical_standards.md` | SQL development standards, table-design standards, batch standards, performance standards |
| `docs/table_lineage.md` | Core table lineage, field lineage, upstream/downstream paths |
| `docs/ref_sql_inventory.md` | Historical SQL inventory, purpose, source tables, target tables, key logic |

Actual output files may be adjusted if the user requests a different structure.

## Workflow

```text
User specifies SQL / ETL scope
        ↓
Confirm blocking uncertainties
        ↓
Discover candidate files and split into batches of at most 3 files
        ↓
        ├─ Single file -> main agent analyzes directly -> write docs -> finish
        │
        └─ Multiple files -> batch loop
                         ↓
             Take current batch (≤3 files)
                         ↓
             Dispatch one Explore subagent per file in parallel
                         ↓
             Wait for all subagents in this batch
                         ↓
             Collect batch blockers and ask once if needed
                         ↓
             Merge batch rules, lineage, inventory, and conflicts
                         ↓
             Write to disk: first batch creates docs; later batches incrementally edit docs
                         ↓
             More files? yes -> next batch
                         ↓ no
             Cross-batch consistency check and conflict resolution
                         ↓
             Output final docs and next-step suggestions
```

## Step 1: Confirm Scope And Blockers

1. Scan the user-specified files/directories and enumerate SQL / ETL files.
2. Ask once if blockers exist:
   - The user did not specify SQL files or directories.
   - The user did not specify output paths and defaults might overwrite existing files.
   - Whether existing documents may be overwritten is unclear.
   - Document granularity, output scope, or file-level detail needs confirmation.

Question rules:

- Collect all current blockers in one prompt.
- Each question must be independently answerable.
- Do not include a follow-up that depends on a previous answer in the same prompt.
- If offering choices, do not add an "Other" option; the user can always type freely.
- Explain why the confirmation is needed and which document or rule it affects.

## Step 2: File Discovery

Scan the specified scope and build a candidate list. Record:

- File path.
- Filename.
- Size or complexity.
- Likely data layer.
- Likely task type.
- Whether segmented analysis is needed.
- Analysis status.

## Step 3: Per-File Independent Analysis

Choose the path by file count.

### Single-File Path

If there is only one SQL file, the main agent analyzes it directly using the "Per-file analysis content" below, produces structured output, and moves to batch merge/write.

### Multi-File Path: Batches + Parallel Explore Subagents

If there are two or more files:

Batching rules:

1. Split files into batches of at most 3 files. For example, 7 files become batches of 3, 3, and 1.
2. Execute batches serially. Finish and write the current batch before starting the next.
3. Within a batch, dispatch subagents in parallel.

Dispatch rules:

1. Each Explore subagent receives exactly one file path and no conclusions from other files or batches.
2. Use the prompt template below.
3. The main agent waits for all subagents in the current batch before merging.
4. If any subagent returns blocking `confirmation_requests`, collect them across the batch, ask the user once, then continue merging.

### Explore Subagent Prompt Template

```text
Analyze the following SQL file independently. Do not depend on conclusions from any other SQL file.

File path: <file_path>

Goals:
1. Identify the script purpose.
2. Identify target tables, source tables, and temp tables.
3. Identify core fields, primary/business keys, join keys, time fields, and partition fields.
4. Identify major processing steps.
5. Identify business rules, filters, status codes, hard-coded values, and special handling.
6. Identify batch variables, rerun logic, and incremental/full-load patterns.
7. Identify technical standards such as temp tables, distribution keys, statistics, and storage parameters.
8. Output table lineage and field lineage.
9. Cite source SQL snippets or line ranges for every conclusion.
10. Do not write unsupported inference as fact; if it affects final docs, put it in confirmation_requests.

Return complete YAML using this structure:
```

### Per-File Analysis Content

Each file analysis must cover:

- Purpose, task type, data layer, and load cycle.
- Target, source, and temp tables.
- Core fields, keys, join keys, time fields, and partition fields.
- Batch variables.
- Major processing steps.
- Table lineage and field lineage.
- Business rules, filters, status codes, and classifications.
- Hard-coded values and special mappings.
- Technical patterns, rerun logic, and performance patterns.
- Validation logic.
- Risks.
- Blocking uncertainties in `confirmation_requests`.

### Structured Output Template

```yaml
file_path:
file_summary:
  purpose:
  task_type:
  data_layer:
  load_cycle:
  target_tables:
  source_tables:
  temp_tables:

lineage:
  table_lineage:
  field_lineage:
  join_paths:

business_rules:
  confirmed_rules:
  inferred_rules:
  status_codes:
  filters:
  hardcoded_mappings:
  exception_rules:

technical_patterns:
  batch_variables:
  partition_fields:
  delete_reload_pattern:
  temp_table_pattern:
  distribution_keys:
  storage_options:
  analyze_usage:
  performance_patterns:

quality_and_risks:
  validations:
  risks:
  confirmation_requests:

evidence:
  key_sql_fragments:
```

## Step 4: Batch Merge And Write

This step has two phases: per-batch merge/write and a final cross-batch consistency check.

### 4a: Per-Batch Merge And Write

Prerequisites: all Explore subagents for the current batch have returned, and batch-level blockers have been resolved.

Merge the structured results:

1. Append file entries to the inventory.
2. Summarize target, source, and temp tables.
3. Merge table lineage and field lineage.
4. Merge business rules, deduplicating existing rules and marking conflicts.
5. Merge technical standards.
6. Summarize hard-coded values, status codes, filters, and special mappings.

Write immediately after merging:

| Batch | Write Strategy |
|---|---|
| First batch | Create all output documents with the initial batch content |
| Later batches | Incrementally edit existing documents; append or merge into relevant sections without clearing prior content |

Incremental editing rules:

- Append new file inventory rows to `docs/ref_sql_inventory.md`.
- Append new lineage nodes and edges to `docs/table_lineage.md`.
- Append newly confirmed business rules to `docs/business_knowledge.md`; deduplicate repeated rules.
- Append newly confirmed technical standards to `docs/technical_standards.md`; if standards conflict, mark the source batch and resolve later.
- Update `AGENTS.md` if new core assets or key decisions should be indexed.

Then start the next batch.

### 4b: Cross-Batch Consistency Check

After all batches are written, perform a global consistency pass:

1. Check whether same-named rules conflict across batches.
2. Check whether the same table has inconsistent lineage or purpose descriptions.
3. Check whether the same field has conflicting definitions.
4. Resolve conclusion-affecting conflicts through one user confirmation prompt.
5. Update the relevant documents and record the resolved decision.
6. Deduplicate confirmed identical rules while preserving all source files.

### Conflict Handling

| Situation | Handling |
|---|---|
| Rules are identical | Merge into one knowledge item and keep all source files |
| Rules are similar but context differs | Record as contextual rules with applicability conditions |
| Rules clearly conflict | Mark as a definition conflict and ask the user to resolve |
| Priority cannot be determined | Ask the user to choose or confirm |

Conflict record format:

```text
Rule name: <rule>
Status: conflict exists / resolved by user confirmation
Sources:
- <file_a.sql>: <rule description>
- <file_b.sql>: <rule description>
Difference: <difference>
Resolution: <confirmed usage or contextual applicability>
```

## Step 5: Generate Documents

Organize documents with progressive disclosure: overview -> topic -> detail -> evidence.

```text
AGENTS.md
  ├─ docs/business_knowledge.md
  │    └─ Business rules, metric definitions, status codes, special handling
  ├─ docs/technical_standards.md
  │    └─ SQL development, batch, and performance standards
  ├─ docs/table_lineage.md
  │    └─ Table lineage, field lineage, upstream/downstream paths
  ├─ docs/ref_sql_inventory.md
  │    └─ SQL inventory, purposes, sources, targets, key logic
```

### AGENTS.md

Keep it concise. Include only summaries, indexes, and navigation:

- One-sentence project overview.
- Data-project structure overview.
- Core directory descriptions.
- Core data asset index.
- Business knowledge index.
- Technical standards index.
- Lineage document index.
- SQL inventory index.
- Key decisions confirmed by the user.
- How future agents should read the documents.

### Placement Rules

| Information Type | Recommended Location |
|---|---|
| Project overview, navigation, core indexes | `AGENTS.md` |
| Business concepts, definitions, status codes, special rules | `docs/business_knowledge.md` |
| SQL style, batch processing, performance, table design | `docs/technical_standards.md` |
| Table-level and field-level lineage | `docs/table_lineage.md` |
| Per-file purpose, sources, targets, evidence snippets | `docs/ref_sql_inventory.md` |
| Resolved conflicts and confirmed decisions | Relevant topic document with confirmation source |

### Cross-Linking

Each detail document should link back to the top-level entry:

```markdown
> Parent entry: [AGENTS.md](../AGENTS.md)
```

`AGENTS.md` should link to all child documents:

```markdown
- [Business Knowledge](docs/business_knowledge.md)
- [Technical Standards](docs/technical_standards.md)
- [Table Lineage](docs/table_lineage.md)
- [SQL Inventory](docs/ref_sql_inventory.md)
```

## Business Knowledge Extraction

Extract from SQL without assuming domain details:

- Business object, metric/component definitions, keys, and join keys.
- Time semantics, status-code meanings, classification rules.
- Filters, exceptions, special mappings.
- Data correction rules and source-system differences.
- Repeated business concepts and reusable join paths.

Each business rule should include:

```text
Rule name:
Rule type: confirmed / inferred / resolved conflict
Description:
Applicable scenario:
Source files:
Source SQL snippets or line ranges:
Related tables:
Related fields:
Risks:
```

## Technical Standards Extraction

Infer technical standards from actual SQL patterns:

- SQL file naming, data-layer naming, table/field/temp-table naming.
- Batch variable usage and time variable usage.
- Partition-field usage, distribution-key habits, storage options.
- Temp-table and intermediate-table patterns.
- Incremental, full-load, and delete-reload patterns.
- Backfill and replay patterns.
- Statistics collection and performance practices.
- Validation/reconciliation and rollback suggestions.

Clearly distinguish:

- **Confirmed patterns** repeated across SQL.
- **Inferred patterns** from limited scripts.
- Patterns requiring user confirmation.

## Lineage Extraction

### Table-Level Lineage

Identify source tables, intermediate tables, temp tables, target tables, upstream/downstream paths, cross-layer processing, multi-source merges, and dimension enrichment.

### Field-Level Lineage

Identify direct mappings, renames, expressions, conditional logic, aggregations, time windows, status transitions, multi-field composition, source priority, defaults, and fallback values.

Do not invent field lineage. If an uncertain field affects final conclusions, ask the user. Otherwise keep the raw SQL evidence without turning it into a conclusion.

## Uncertainty Resolution

### Must Ask The User When

1. No SQL file or directory is specified.
2. Output path is unspecified and defaults may affect existing files.
3. Whether to overwrite existing documents is unclear.
4. Multiple target tables or candidate entry documents conflict.
5. The same rule conflicts across SQL files and final docs need one primary definition.
6. A key field's meaning cannot be confirmed but later analysis depends on it.
7. A hard-coded value, status code, or filter may or may not be a general rule.
8. The user wants definitive standards but SQL evidence is insufficient.
9. Document granularity, output scope, or file-level detail needs confirmation.

### Non-Blocking Uncertainty

For uncertainty that does not affect current conclusions:

1. Keep only raw SQL evidence without explaining meaning.
2. Exclude it from definitive rules.
3. Mark it as a local pattern observed only in source SQL.
4. Ask later only if it must be promoted to a project rule.

### Recording User Confirmations

Write confirmed decisions into the relevant document's decision-record section:

```text
Decision:
Confirmed result:
Confirmation source: user confirmation
Impact scope:
Application:
```

## Evidence Requirements

Every key conclusion should keep evidence:

- Source file path.
- SQL snippet.
- Line range.
- Table and field names.
- Condition expression.
- Comment text.
- Repeated pattern.

Unsupported inference must never be written as confirmed fact.

## Main Prompt Template

```text
Perform a production-SQL reverse initialization for the current data project based on the historical SQL / ETL script directory specified by the user.

Requirements:
- Stay domain-neutral; do not assume any business domain, database, table, or metric.
- Do not merely summarize SQL files.
- Reverse-extract reusable project knowledge from historical SQL.
- For one SQL file, the main agent analyzes directly.
- For multiple files, split into batches of at most 3 files. Run batches serially and dispatch one Explore subagent per file in parallel within a batch.
- After all subagents in each batch return, merge and write immediately: first batch creates files, later batches incrementally edit.
- Each Explore subagent analyzes only one file and cannot depend on other files.
- After all content is written, run a cross-batch consistency check and resolve conflicts.
- Preserve source files for every rule during global merge.
- Distinguish confirmed rules, inferred rules, and resolved-conflict rules.
- Do not perform database writes.

Generate project-level documents: project overview, business knowledge base, technical standards, table lineage, and SQL inventory. Final documents must not contain unresolved questions.
```

## Acceptance Criteria

The output is acceptable when:

- Future developers can quickly understand the project structure.
- Future agents can choose appropriate historical SQL references from the docs.
- Core table sources, purposes, keys, time fields, partition fields, and join paths are clear.
- Common business rules and technical standards are abstracted.
- Special rules, hard-coded values, status codes, and filters are recorded separately.
- Conflicting definitions across SQL files are explicitly marked and resolved.
- Final documents contain no unresolved questions.
- Documents do not mix confirmed rules, inferred rules, and user-confirmed decisions.
- Content remains domain-neutral and reusable.
