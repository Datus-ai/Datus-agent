---
name: data-compare
description: Use user-provided or user-designated reference data to reconcile ETL job results, discover business-logic defects, and correct jobs SQL. Use when the user asks for data reconciliation, benchmark comparison, metric checking, variance analysis, inconsistent results, SQL correction based on reference data, rerun validation, or iterative fixes until the business definition is correct, especially after execute-job or when benchmark/reference values are provided. Reference data is evidence for calibrating business logic; exact matching is a validation signal, not the final goal.
tags: [data-quality, reconciliation, etl, sql, debugging, business-logic]
version: "1.1.0"
user_invocable: true
---

# Data Compare

Compare user-provided, user-specified, or user-approved reference data with target results produced by SQL under `jobs/`. Use differences to find problems in business definitions, filters, date boundaries, dimension mappings, amount signs, and other SQL logic. Iterate through compare, diagnose, edit, rerun, and verify until the business logic is corrected and key reconciliation checks pass, or until a user/business decision is required.

**Positioning**: reference data is evidence for calibrating and correcting SQL business logic. A matching comparison result is a way to find issues and validate fixes; it is not the final objective. Do not hard-code differences, fake adjustment logic, delete anomalous samples, or force numbers to match without a business basis. The final goal is correct, rerunnable, explainable job SQL with a clear evidence chain.

## Principles

1. **Business logic first**: every reconciliation step should help discover and fix SQL business logic. Do not treat "numbers happen to match" as the only success criterion.
2. **Reference data is evidence, not an oracle**: reference data is usually trusted, but still verify its batch, grain, filters, unit, extraction time, and applicability. If its definition is unclear, mark it for confirmation.
3. **Iterate when authorized**: when the user allows job edits, run multiple loops of compare -> diagnose -> modify `jobs/` SQL -> rerun -> compare. Each loop must state which business logic changed.
4. **No cheating for a match**: do not hard-code keys, write reference values into SQL, arbitrarily exclude difference records, bypass real sources, or add adjustment logic without a business reason.
5. **Evidence-driven fixes**: every fix needs support from difference statistics, samples, source/target fields, SQL snippets, project docs, or user confirmation.
6. **Small, explainable changes**: edit only the `jobs/` SQL causing the difference. Preserve batch variables, temp-table style, idempotent rerun logic, and project standards.
7. **Expose uncertainty**: ask the user when the reference definition, tolerance, dimension mapping, fix direction, or business meaning cannot be determined.
8. **Protect reference assets**: treat `ref_sql/`, `docs/`, and user-provided reference data as read-only unless the user explicitly asks for a separate development change.

## When To Use

Use this skill for requests such as:

- Compare job output against reference/correct data.
- Reconciliation failed; analyze differences and modify SQL.
- Use these reference numbers to correct business logic, then rerun and verify.
- Results after `execute-job` do not match a standard table or manually provided values.
- Keep updating the job SQL until the business definition is correct and reconciliation passes.
- Explain which SQL logic causes the variance between this metric and the reference report.

Do not use it when:

- The user only wants to execute a job, without reconciliation or logic correction.
- The work is a brand-new ETL design with no executable job SQL or comparable result.
- The user only wants a one-off query of reference data and does not need SQL fixes.
- No reference data is provided or inferable, and the user is not asking to design a comparison approach.

## Required Inputs

Infer these from the user request, SQL files, project docs, and database metadata when possible. Ask only when they cannot be reliably determined.

| Input | Meaning | Common Example |
|---|---|---|
| `batch_date` | Batch date for job execution and reconciliation, usually `YYYYMMDD` | `20260430` |
| Job SQL | The modifiable SQL under `jobs/` | `jobs/rdm_xxx.sql` |
| Actual result | Target table and filters written by the job | `dmrdm_data.xxx where etl_dt=...` |
| Reference data | User-provided or approved benchmark: table, SQL, CSV, manual values, report extract, historical result | `select ... from standard_table` |
| Reference definition | Batch, grain, filters, units, amount signs, null and rounding rules | month-end balance, org + product grain, unit CNY |
| Comparison grain | Keys or dimensions used for aggregation and drilldown | date, org, product, customer, loan id |
| Metric fields | Amounts, balances, counts, status fields, etc. | `loan_bal`, `cnt`, `five_class_cd` |
| Tolerance | Numeric tolerance, null equivalence, rounding rules | `abs(diff) <= 0.01` |
| Edit authorization | Whether SQL can be modified and rerun | "fix it until it passes" |

Ask once if any execution-blocking item is missing:

1. `batch_date`;
2. job SQL file;
3. reference source, values, or SQL;
4. reference business definition, batch, grain, filters, and units;
5. comparison keys or dimensions;
6. numeric tolerance, rounding, or null handling;
7. permission to edit `jobs/` SQL and rerun.

## Workflow

```text
Receive reconciliation / variance-fix request
  ↓
Identify job, target table, batch, reference data, and reference definition
  ↓
Ask once if blocking information is missing
  ↓
Read job SQL, project docs, and relevant table metadata
  ↓
Run or reuse job output
  ↓
Build reproducible comparison SQL
  ↓
Report difference statistics, samples, and impact
  ↓
Infer the SQL business-logic issue indicated by the differences
  ↓
Make the smallest jobs SQL change and record the business evidence
  ↓
Rerun the same batch
  ↓
Compare again to validate the fix
  ↓
Pass: report the business-logic correction; fail: continue iterating or state the blocker
```

## Step 1: Identify Objects And Definitions

Extract:

- Job file: must be under `jobs/`; bare filenames resolve to `jobs/<name>.sql`.
- Batch date: parse `batch_date` and derive month start, previous month end, year start, etc.
- Target table: infer from `INSERT INTO`, `DELETE FROM`, `ANALYZE`, comments, or filename.
- Reference data: table, user SQL, fixed values, CSV/report summary, or known correct result.
- Reference definition: business meaning, not just numeric value.
- Comparison grain: prefer business keys/report dimensions; if not unique, compare totals first, then drill down.
- Metric fields: handle amounts, balances, counts, statuses, and dates differently.

## Step 2: Read-Only Exploration And Metadata Checks

Before editing:

- Read the job SQL and understand target table, sources, temp tables, filters, partitions, and rerun logic.
- Check relevant sections in `docs/business_knowledge.md`, `docs/technical_standards.md`, `docs/table_lineage.md`, and `docs/ref_sql_inventory.md`.
- Use database metadata tools to inspect the target, reference, and key source table structures, partition fields, and control fields.
- Sample queries must use `LIMIT 10-20`; aggregate comparisons may run without sample limits, but avoid unnecessary full-detail scans.

Verify:

- Reference and actual results use the same batch, accounting period, and statistical time point.
- Schema, casing, and layer are correct.
- `etl_dt`, `etl_task_no`, and partition dates match the batch.
- Month-end, previous month end, year start, 13-month rolling windows, CDC `id_mark`, and zipper `start_dt/end_dt` follow project standards.
- Code mapping, org/product hierarchy, and special exclusions match project knowledge.
- Duplicates, missing filters, join type mistakes, date-boundary errors, amount signs, unit conversion, and precision issues are checked.

## Step 3: Run Or Reuse Job Output

If the user already ran the job, reuse the existing target result and record the batch.

If a rerun is needed:

- Use the project's `execute-job` workflow for SQL under `jobs/`.
- Do not execute `ref_sql/`.
- Verify idempotency before rerun: the SQL should delete/overwrite the current batch or partition safely.
- Record each run's job file, batch, exit code, errors, and elapsed time.

## Step 4: Build Comparison SQL

### 4.1 Total Comparison

```sql
select 'reference' as src, count(*) as row_cnt, sum(metric_amt) as metric_amt
from <reference_source>
where <reference_batch_filter>
union all
select 'actual' as src, count(*) as row_cnt, sum(metric_amt) as metric_amt
from <actual_target>
where <actual_batch_filter>;
```

This shows whether a difference exists and its scale. It does not prove root cause.

### 4.2 Dimensional Aggregate Comparison

Aggregate by comparison grain to avoid detail-level duplication:

```sql
with ref as (
  select <keys>, sum(<metric>) as metric_amt, count(*) as row_cnt
  from <reference_source>
  where <reference_filter>
  group by <keys>
), act as (
  select <keys>, sum(<metric>) as metric_amt, count(*) as row_cnt
  from <actual_target>
  where <actual_filter>
  group by <keys>
)
select
  coalesce(ref.<key>, act.<key>) as <key>,
  ref.metric_amt as ref_metric_amt,
  act.metric_amt as act_metric_amt,
  act.metric_amt - ref.metric_amt as diff_metric_amt,
  ref.row_cnt as ref_row_cnt,
  act.row_cnt as act_row_cnt,
  case
    when ref.<key> is null then 'actual_only'
    when act.<key> is null then 'reference_only'
    when abs(coalesce(act.metric_amt,0) - coalesce(ref.metric_amt,0)) > <tolerance> then 'metric_diff'
    else 'pass'
  end as diff_type
from ref
full outer join act
  on <key_join_conditions>
where ref.<key> is null
   or act.<key> is null
   or abs(coalesce(act.metric_amt,0) - coalesce(ref.metric_amt,0)) > <tolerance>
limit 20;
```

### 4.3 Field-Level Comparison

After totals or dimensional checks identify concrete keys:

- Pull only difference samples, `LIMIT 10-20`.
- Normalize dates, amounts, codes, and null values before comparing.
- Separately mark differences caused by `NULL` vs blank, sentinel dates, unit conversion, or rounding.
- Trace differing fields back to job SQL sources, joins, `case when`, filters, or grouping.

## Step 5: Infer Business-Logic Root Cause

Investigate in this order:

1. **Batch/time point**: `etl_dt`, `batch_date`, month end, year start, previous month-end baseline, or partition condition mismatch.
2. **Business scope**: missing or extra business lines, orgs, products, account types, special exclusions, or status filters.
3. **Join logic**: wrong join type, incomplete keys, multi-version dimensions without date filters, duplicate dimension rows.
4. **Incremental/rerun logic**: old batch not deleted, missing task number filter, CDC `id_mark` error, missing zipper validity condition.
5. **Metric definition**: amount signs, units, balance time point, five-level classification, new non-performing logic, write-off/recovery, batch transfer, provisions.
6. **Code/hierarchy mapping**: `m_pb_pub_cd_map`, product/org hierarchy, business-line markers, missing mapping defaults.
7. **Data quality**: source gaps, duplicates, nulls, abnormal dates, missing historical adjustments.
8. **Precision**: decimal precision, rounding, tolerance mismatch.

Each root-cause conclusion must include:

- Difference phenomenon: amount, keys, fields.
- Business interpretation: which logic is likely wrong.
- Evidence: comparison SQL summary, samples, source fields, or job SQL snippets.
- Fix location: file, SQL section, field, or condition.
- Expected impact: which difference class should shrink.
- Whether business confirmation is still needed.

## Step 6: Modify Jobs SQL

Only edit SQL under `jobs/` after the root cause is confirmed. The edit must correct business logic, not force a numeric match.

Requirements:

- Preserve names, variables, transactions, partitions, `ANALYZE`, and temp-table style.
- Keep the diff minimal.
- Record the old logic problem and the evidence exposed by reference data.
- Do not edit `ref_sql/`, `docs/`, or database object definitions unless the user explicitly requests a separate development task.
- Ask first if a change alters business definitions, target schema, historical range, or adjustment strategy.
- Never hard-code reference values, difference keys, or businessless filters just to pass reconciliation.

Common fixes:

| Root Cause | Fix Direction |
|---|---|
| Wrong batch filter | Standardize `date'${batch_date}'`, `${month_start}`, `${last_month_end}`, etc. |
| Wrong reference time point | Align actual logic to the reference's month-end, end-of-day, year-start, or prior-month baseline |
| Join amplification | Add keys, deduplicate dimensions, filter validity periods, or choose latest version |
| Missing data | Correct filters, use the appropriate outer join, add business-line/product scope |
| Extra data | Add status, business-line, task-number, or partition filters; exclude invalid records |
| Amount difference | Correct signs, units, aggregation grain, null handling, and rounding |
| Code difference | Fix mapping, defaults, or unmapped-code handling |
| Rerun pollution | Add target-batch delete conditions or `etl_task_no` filters |
| Unclear definition | Do not force a fix; report differences and candidate explanations for confirmation |

## Step 7: Rerun And Compare Again

After each edit:

1. Save the job SQL.
2. Rerun the same `batch_date`.
3. Re-run the same comparison SQL.
4. Compare this round's differences with the previous round.
5. State which business logic this round validated.
6. If differences shrink but do not pass, continue diagnosing the remainder.
7. If differences grow or new errors appear, review and adjust the latest edit.

Stop conditions:

- **Pass**: key metrics are within tolerance, missing/extra keys are zero, and the fix has a business basis.
- **Not passed but diagnosed**: differences remain, but root cause is clear and requires more development, upstream data repair, or user confirmation.
- **Blocked**: reference definition is unclear, reference data is untrusted, source data is missing, permissions/execution failed, or the fix needs business confirmation.
- **Out of scope**: the change requires a new table, full pipeline refactor, or upstream standard-definition change; switch to the formal development-plan workflow.

## Output Format

Final user-facing report:

```markdown
# Reconciliation And Business-Logic Correction Report: <job or target table>

## 1. Inputs
- batch_date: <YYYYMMDD>
- job SQL: <jobs/xxx.sql>
- target table: <schema.table>
- reference source: <table/sql/user provided>
- reference definition: <batch/grain/filter/unit/time point>
- comparison grain: <keys>
- metric fields and tolerance: <metrics/tolerance>

## 2. Conclusion
- status: pass / not passed / blocked
- core judgment: <SQL business logic corrected / definition still uncertain / reference data needs confirmation>
- total row-count difference: <...>
- key metric difference: <...>
- differing key count: <...>

## 3. Differences
| diff_type | key_count | ref_value | actual_value | diff | indicated issue |
|---|---:|---:|---:|---:|---|

## 4. Business-Logic Root Causes
- root cause 1: <phenomenon, business explanation, evidence, impact>
- root cause 2: <phenomenon, business explanation, evidence, impact>

## 5. Changes Made
| File | Location | Problem Before | Fix Direction | Business Evidence |
|---|---|---|---|---|

## 6. Rerun And Verification
| Round | Action | Validation Result | Remaining Difference | Conclusion |
|---|---|---|---|---|

## 7. Remaining Risks / Confirmation Needed
- <write "none" if there are none>
```

## Examples

### Example 1: Reference balance reveals a product filter bug

1. Confirm reference source, target table, comparison keys, amount tolerance, and edit authorization.
2. Reuse or rerun the `20260430` target result.
3. Compare totals first, then drill down by org/product/loan id.
4. Find that one product line is missing from the target.
5. Check job SQL and docs; confirm the product line should be included.
6. Edit the product filter in `jobs/rdm_e_ar_loan_dubil_incl_crdt_card.sql`.
7. Rerun and report that the product-scope logic was corrected, not merely that the number matches.

### Example 2: Reference data reveals a missing delete-marker filter

1. Use a full outer join to find `actual_only` loans.
2. Sample source statuses, batch fields, and `id_mark`.
3. Discover all extra records are delete-marked.
4. Confirm the job omitted `id_mark='I'`.
5. Add the filter and rerun.
6. Confirm `actual_only` is zero and report that the valid-snapshot rule is now enforced.

### Example 3: Do not chase a number blindly

If the user says "reference is 1000, actual is 998, just change it to 1000":

1. Do not hard-code 1000.
2. Verify the reference batch, dimension, and unit.
3. Drill into the difference of 2.
4. If the target SQL missed a business record class, fix the filter or join.
5. If the business meaning is unclear, report a blocker and ask for confirmation.

## Notes

- Do not hard-code difference keys, reference amounts, or temporary adjustments just to pass reconciliation unless the user explicitly requests an adjustment and the report labels it as an adjustment, not a business-logic fix.
- Do not hide unresolved differences. If out-of-tolerance differences remain, status must be "not passed" or "blocked".
- Do not extrapolate from samples alone; conclusions need aggregate statistics and reproducible SQL.
- Do not change core business rules without confirming the definition.
- Before rerunning against production-sensitive tables, confirm idempotency and batch scope.
- After reference and actual data match, still explain which business-logic corrections caused the match. If differences merely offset each other by accident, do not mark the result as passed.
