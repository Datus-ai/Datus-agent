CREATE SCHEMA IF NOT EXISTS marts;

CREATE OR REPLACE TABLE marts.pendo__feature AS
WITH feature_event_metrics AS (
    SELECT
        feature_id,
        COUNT(DISTINCT visitor_id) AS count_visitors,
        COUNT(DISTINCT account_id) AS count_accounts,
        SUM(num_events) AS sum_clicks,
        COUNT(*) AS count_click_events,
        MIN(occurred_at) AS first_click_at,
        MAX(occurred_at) AS last_click_at,
        CASE WHEN COUNT(DISTINCT visitor_id) = 0 THEN NULL ELSE SUM(num_minutes) / COUNT(DISTINCT visitor_id) END AS avg_visitor_minutes,
        CASE WHEN COUNT(DISTINCT visitor_id) = 0 THEN NULL ELSE SUM(num_events) / COUNT(DISTINCT visitor_id) END AS avg_visitor_events
    FROM staging.stg_pendo__feature_event
    GROUP BY feature_id
)
SELECT
    f.feature_id,
    f.app_id,
    f.created_at,
    f.created_by_user_id,
    f.is_dirty,
    f.group_id,
    f.is_core_event,
    f.last_updated_at,
    f.last_updated_by_user_id,
    f.feature_name,
    f.page_id,
    f.root_version_id,
    f.stable_version_id,
    f.valid_through,
    f.page_name,
    f.page_created_at,
    f.page_valid_through,
    COALESCE(m.count_visitors, 0) AS count_visitors,
    COALESCE(m.count_accounts, 0) AS count_accounts,
    COALESCE(m.sum_clicks, 0) AS sum_clicks,
    COALESCE(m.count_click_events, 0) AS count_click_events,
    m.first_click_at,
    m.last_click_at,
    COALESCE(ROUND(m.avg_visitor_minutes, 3), 0) AS avg_visitor_minutes,
    COALESCE(ROUND(m.avg_visitor_events, 3), 0) AS avg_visitor_events
FROM intermediate.int_pendo__feature_info AS f
LEFT JOIN feature_event_metrics AS m
    ON f.feature_id = m.feature_id;
