CREATE SCHEMA IF NOT EXISTS marts;

CREATE OR REPLACE TABLE marts.pendo__feature_event AS
WITH feature_events AS (
    SELECT
        e.*,
        LAG(feature_id) OVER (
            PARTITION BY visitor_id
            ORDER BY occurred_at
        ) AS previous_feature_id,
        LAG(occurred_at) OVER (
            PARTITION BY visitor_id
            ORDER BY occurred_at
        ) AS previous_feature_event_at,
        LAG(num_minutes) OVER (
            PARTITION BY visitor_id
            ORDER BY occurred_at
        ) AS previous_feature_num_minutes,
        LAG(num_events) OVER (
            PARTITION BY visitor_id
            ORDER BY occurred_at
        ) AS previous_feature_num_events
    FROM staging.stg_pendo__feature_event AS e
)
SELECT
    e.account_id,
    e.app_id,
    e.feature_id,
    e.num_events,
    e.num_minutes,
    e.remote_ip,
    e.server_name,
    e.occurred_at,
    e.user_agent,
    e.visitor_id,
    e.feature_event_key,
    e.previous_feature_id,
    e.previous_feature_event_at,
    e.previous_feature_num_minutes,
    e.previous_feature_num_events,
    f.feature_name,
    f.page_id,
    f.page_name,
    f.group_id AS product_area_id,
    pf.feature_name AS previous_feature_name,
    pf.page_id AS previous_feature_page_id,
    pf.page_name AS previous_feature_page_name,
    pf.group_id AS previous_feature_product_area_id
FROM feature_events AS e
INNER JOIN intermediate.int_pendo__feature_info AS f
    ON e.feature_id = f.feature_id
LEFT JOIN intermediate.int_pendo__feature_info AS pf
    ON e.previous_feature_id = pf.feature_id;
