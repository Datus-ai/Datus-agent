CREATE SCHEMA IF NOT EXISTS staging;

CREATE OR REPLACE TABLE staging.stg_pendo__page_history AS
SELECT
    id AS page_id,
    name AS page_name,
    app_id,
    TRY_CAST(SUBSTRING(created_at, 1, 23) AS TIMESTAMP) AS created_at,
    created_by_user_id,
    dirty AS is_dirty,
    group_id,
    TRY_CAST(SUBSTRING(last_updated_at, 1, 23) AS TIMESTAMP) AS last_updated_at,
    last_updated_by_user_id,
    root_version_id,
    stable_version_id,
    TRY_CAST(SUBSTRING(valid_through, 1, 23) AS TIMESTAMP) AS valid_through
FROM raw.page_history
WHERE id IS NOT NULL
  AND id != '';
