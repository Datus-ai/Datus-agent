CREATE SCHEMA IF NOT EXISTS staging;

CREATE OR REPLACE TABLE staging.stg_pendo__feature_event AS
SELECT
    account_id,
    feature_id,
    NULLIF(TRIM(remote_ip), '') AS remote_ip,
    NULLIF(TRIM(server_name), '') AS server_name,
    TRY_CAST(SUBSTRING(timestamp, 1, 23) AS TIMESTAMP) AS occurred_at,
    NULLIF(TRIM(user_agent), '') AS user_agent,
    visitor_id,
    app_id,
    CASE WHEN num_events >= 0 THEN num_events END AS num_events,
    CASE WHEN num_minutes >= 0 THEN num_minutes END AS num_minutes,
    MD5(CONCAT_WS('|', visitor_id, timestamp, account_id, app_id, feature_id, server_name, user_agent, remote_ip)) AS feature_event_key
FROM raw.feature_event
WHERE visitor_id IS NOT NULL AND visitor_id != ''
  AND account_id IS NOT NULL AND account_id != ''
  AND app_id IS NOT NULL AND app_id != ''
  AND feature_id IS NOT NULL AND feature_id != ''
  AND timestamp IS NOT NULL;
