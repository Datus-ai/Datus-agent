CREATE SCHEMA IF NOT EXISTS intermediate;

CREATE OR REPLACE TABLE intermediate.int_pendo__feature_info AS
SELECT
    f.feature_id,
    f.app_id,
    f.created_at,
    f.created_by_user_id,
    f.is_dirty,
    f.group_id,
    f.is_core_event,
    f.last_updated_at,
    f.last_updated_by_user_id,
    f.feature_name,
    f.page_id,
    f.root_version_id,
    f.stable_version_id,
    f.valid_through,
    p.page_name,
    p.created_at AS page_created_at,
    p.valid_through AS page_valid_through
FROM intermediate.int_pendo__latest_feature AS f
LEFT JOIN intermediate.int_pendo__latest_page AS p
    ON f.page_id = p.page_id;
