CREATE SCHEMA IF NOT EXISTS intermediate;

CREATE OR REPLACE TABLE intermediate.int_pendo__latest_page AS
WITH ranked_pages AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY page_id
            ORDER BY last_updated_at DESC
        ) AS latest_page_index
    FROM staging.stg_pendo__page_history
)
SELECT *
FROM ranked_pages
WHERE latest_page_index = 1;
