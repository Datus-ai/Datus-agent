CREATE SCHEMA IF NOT EXISTS intermediate;

CREATE OR REPLACE TABLE intermediate.int_pendo__latest_feature AS
WITH ranked_features AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY feature_id
            ORDER BY last_updated_at DESC
        ) AS latest_feature_index
    FROM staging.stg_pendo__feature_history
)
SELECT *
FROM ranked_features
WHERE latest_feature_index = 1;
