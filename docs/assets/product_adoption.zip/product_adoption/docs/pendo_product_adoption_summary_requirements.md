# Pendo Product Adoption Summary Business Requirements

## 1. Business Context

Product, Customer Success, and Growth teams need a consistent way to measure how customers adopt product features across applications. Individual click events show isolated activity, but they do not indicate whether a feature has been meaningfully adopted by a customer account.

The `pendo__product_adoption_summary` table provides a feature-level adoption summary by customer account and application. It supports product adoption analysis, customer enablement, lifecycle campaigns, health monitoring, and feature adoption reporting.

## 2. Business Objectives

This table is designed to answer the following business questions:

- Which customer accounts are using each product feature?
- How deeply has a feature been adopted by a customer within an application?
- Is a customer only trying a feature, using it casually, using it regularly, or using it heavily?
- Which features need additional onboarding, education, or in-product guidance?
- Which customers show strong feature adoption and are candidates for expansion, advocacy, or advanced enablement?

## 3. Scope and Grain

The table is built from cleaned feature interaction events in `staging.stg_pendo__feature_event`.

Each row represents the cumulative adoption profile for one feature within one customer account and one application.

Business grain:

```text
Feature ID + Account ID + Application ID
```

| Dimension | Field | Business Meaning |
|---|---|---|
| Feature | `feature_id` | The product feature that was used or clicked. |
| Account | `account_id` | The customer account or tenant using the feature. |
| Application | `app_id` | The application where the feature usage occurred. |

## 4. Dimension Requirements

### 4.1 Feature

The business needs to analyze adoption at the feature level to understand which product capabilities are being used, underused, or heavily adopted.

Definition: use `feature_id` from the feature event data as the feature identifier.

### 4.2 Account

The business needs to evaluate adoption by customer account to support customer success actions, renewal analysis, customer segmentation, and feature enablement campaigns.

Definition: use `account_id` from the feature event data as the customer account identifier.

### 4.3 Application

The same customer or feature may appear across multiple applications. Application-level separation prevents usage from different product contexts from being blended together.

Definition: use `app_id` from the feature event data as the application identifier.

## 5. Metric Requirements and Calculation Rules

| Metric | Field | Business Purpose | Calculation Rule |
|---|---|---|---|
| Total Users | `total_users` | Measures feature reach within a customer account. | Count distinct `visitor_id` within each `feature_id + account_id + app_id`; null `visitor_id` values are excluded. |
| Usage Sessions | `usage_sessions` | Measures the number of recorded feature usage sessions or interaction records. | Count all feature event records within each `feature_id + account_id + app_id`. |
| Total Events | `total_events` | Measures total feature interaction volume. | Sum `num_events` within each grain; null values are ignored. If all values are null, the result is null. |
| Total Minutes | `total_minutes` | Measures total time spent in feature-related activity. | Sum `num_minutes` within each grain; null values are ignored. If all values are null, the result is null. Unit: minutes. |
| Active Days | `active_days` | Measures sustained usage over time, not just one-time activity. | Count distinct calendar dates derived from `occurred_at`; null timestamps are excluded. |
| Average Events per Session | `avg_events_per_session` | Measures average interaction depth per usage record. | Average `num_events` within each grain; null values are ignored. If all values are null, the result is null. |
| Average Minutes per Session | `avg_minutes_per_session` | Measures average time spent per usage record. | Average `num_minutes` within each grain; null values are ignored. If all values are null, the result is null. |
| Adoption Level | `adoption_level` | Converts usage behavior into a business-friendly adoption segment. | Classify each row using active days and total events. Rules are defined in Section 6. |
| Feature Health Score | `feature_health_score` | Provides a single score for ranking feature adoption health across accounts and applications. | Calculate the score using user reach, average interaction depth, and active days. Rules are defined in Section 7. |
| Calculated At | `calculated_at` | Records when the metrics were generated. | Use the system timestamp at calculation time. |

## 6. Adoption Level Rules

Adoption level classifies customer feature usage into five business segments. Rules are evaluated in order from highest adoption to lowest adoption.

| Adoption Level | Business Meaning | Rule |
|---|---|---|
| Power Users | The feature is deeply adopted and has become a high-frequency capability for the customer. | `active_days >= 20` and `total_events >= 100` |
| Regular Users | The customer uses the feature consistently and has formed a stable usage habit. | `active_days >= 10` and `total_events >= 50` |
| Casual Users | The customer has meaningful but not yet consistent feature usage. | `active_days >= 5` and `total_events >= 20` |
| Trial Users | The customer has started trying the feature. | `active_days >= 1` and `total_events >= 5` |
| Minimal Users | Feature usage is very low and does not meet the trial threshold. | Any row that does not meet the rules above. If `total_events` is null, classify as `Minimal Users`. |

## 7. Feature Health Score

Feature health score summarizes adoption strength for a feature within a customer account and application. The score balances user reach, interaction depth, and sustained usage.

Formula:

```text
feature_health_score = total_users * 2
                     + avg_events_per_session * 5
                     + active_days * 3
```

Capping rule:

```text
If feature_health_score > 100, return 100.
```

Null handling:

- If there are no non-null `num_events` values, `feature_health_score` is null.
- The score is not rounded.
- No minimum score floor is applied.

Business interpretation:

- Higher `total_users` indicates broader feature reach within the account.
- Higher `avg_events_per_session` indicates deeper interaction per usage session.
- Higher `active_days` indicates more sustained adoption over time.

## 8. Business Use Cases

Product analysis:

- Identify features with high or low adoption.
- Compare adoption of the same feature across customer accounts.
- Distinguish sustained adoption from short-lived launch activity.

Customer success:

- Identify accounts that need feature training or onboarding support.
- Identify highly adopted features for renewal, expansion, or advocacy conversations.
- Assess whether customers are using key product capabilities.

Growth and operations:

- Segment accounts by adoption level for targeted campaigns.
- Activate Trial Users and Minimal Users through education or in-product guidance.
- Recommend advanced workflows to Regular Users and Power Users.

## 9. Output Fields

| Field | Type | Role |
|---|---|---|
| `feature_id` | VARCHAR | Dimension |
| `account_id` | VARCHAR | Dimension |
| `app_id` | VARCHAR | Dimension |
| `total_users` | BIGINT | Metric |
| `usage_sessions` | BIGINT | Metric |
| `total_events` | DOUBLE | Metric |
| `total_minutes` | DOUBLE | Metric |
| `active_days` | BIGINT | Metric |
| `avg_events_per_session` | DOUBLE | Metric |
| `avg_minutes_per_session` | DOUBLE | Metric |
| `adoption_level` | VARCHAR | Derived segment |
| `feature_health_score` | DOUBLE | Derived score |
| `calculated_at` | TIMESTAMP WITH TIME ZONE | Audit field |
